# DDROID — vibe coding development record

Prototype: **2.0, Node-RED functional simulation**  
Date: **16 October 2026**

## Requirements given to the coding assistant

The class required a quick working prototype using vibe coding and one of XOD, Node-RED, or ROS 2 with Gazebo. The team needed the same simulation to run on Ubuntu and Windows after sharing it through WhatsApp.

The approved project is a stationary livestock watering and monitoring machine. Its proposal specifies safe startup, explicit arming, automatic refill, float filtering, pump protection, fault latching, local Stop, manual limits and operation during network loss.

## Implementation prompt used for this build

> Build a Node-RED prototype of DDROID's livestock watering system using only built-in nodes. Simulate the supply tank, trough, float switches and pump. Provide an animated browser dashboard and controls for normal operation, low supply, sensor conflict, independent cutoff, blocked flow and network loss. Require two stable sensor samples, explicit arming, bounded manual pumping, run timeout and safe fault reset. Freeze dashboard telemetry during network loss while local control continues. Provide event export, Ubuntu and Windows launchers, locked dependencies and tests. Keep readings clearly synthetic and the service local to the PC.

This is a consolidated implementation prompt reflecting the requirements used in this build; it is not represented as a transcript of an earlier team session.

## Decisions and checks

1. Selected Node-RED after checking its official setup and sharing documentation.
2. Used core nodes and a self-contained Template dashboard to reduce installation differences.
3. Kept control logic inside a Node-RED Function node, with a readable source copy for review.
4. Pinned Node-RED 5.0.8 and recommended Node.js 24 LTS for every computer.
5. Implemented fault scenarios and automated checks, then exercised the real Linux Node-RED runtime and browser interface.
6. Prepared a source ZIP with separate Ubuntu and Windows launchers. Hardware safety and Windows execution are not claimed as verified by software-only Linux checks.

AI-assisted generation produced the initial code, packaging and tests. The included test results distinguish executed checks from checks still needed on the group's devices.

## Group review before demonstration

- Software and systems leads should inspect the control transitions and assumptions.
- The test lead should repeat `npm test` and the dashboard smoke check on the group's computers.
- A Windows member should perform the launcher check recorded in README.md.
- The group should record actual feedback and changes after review; no completed group review is claimed here.

After the requirements review, archive this throwaway prototype. Implement and validate the physical controller separately. Simulated shutdown timing does not prove hardware performance.
