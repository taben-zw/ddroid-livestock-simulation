@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 goto missing
where npm.cmd >nul 2>&1
if errorlevel 1 goto missing
node check-node.js
if errorlevel 1 goto failed
if not exist "node_modules\node-red\red.js" goto setup
if exist "node_modules\.ddroid-ready-5.0.8" goto launch
:setup
echo First setup: downloading pinned Node-RED dependencies. Internet is required.
call npm.cmd ci --omit=optional --no-audit --no-fund
if errorlevel 1 goto failed
node -e "require('node:fs').writeFileSync('node_modules/.ddroid-ready-5.0.8','ready')"
if errorlevel 1 goto failed
:launch
node start.js %*
if errorlevel 1 goto failed
exit /b 0
:missing
echo Install Node.js 24 LTS with npm from https://nodejs.org/en/download
echo Then close and reopen this launcher. Extract the ZIP before running it.
:failed
echo.
echo Setup or launch did not complete. Read the message above and START_HERE.html.
pause
exit /b 1
