'use strict';
require('./check-node');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const net=require('node:net');
const {spawn}=require('node:child_process');
const args=process.argv.slice(2);
const pos=args.indexOf('--port');
const port=pos>=0?Number(args[pos+1]):1880;
if(!Number.isInteger(port)||port<1024||port>65535){console.error('Choose a port from 1024 to 65535: npm start -- --port 1881');process.exit(1)}
const red=path.join(__dirname,'node_modules','node-red','red.js');
if(!fs.existsSync(red)){console.error('Run the platform launcher first, or run: npm ci --omit=optional');process.exit(1)}
const installed=require('./node_modules/node-red/package.json').version;
if(installed!==require('./package.json').dependencies['node-red']){console.error('The installed Node-RED version differs from the project. Run: npm ci --omit=optional');process.exit(1)}
const probe=net.createServer();
probe.once('error',()=>{console.error('Port '+port+' is busy. Stop your other Node-RED instance or use: npm start -- --port 1881');process.exitCode=1});
probe.listen(port,'127.0.0.1',()=>probe.close(launch));
function launch(){
 const runtime=path.join(__dirname,'runtime');fs.mkdirSync(runtime,{recursive:true});
 const base='http://127.0.0.1:'+port;
 console.log('\nDDROID simulation: '+base+'/ddroid\nNode-RED editor: '+base+'/red/\nKeep this terminal open. Press Ctrl+C to stop.\n');
 const child=spawn(process.execPath,[red,'--userDir',runtime,'--settings',path.join(__dirname,'settings.js')],{cwd:__dirname,stdio:'inherit',env:{...process.env,DDROID_PORT:String(port)}});
 let attempts=0,timer,done=false;
 function openBrowser(){
  if(args.includes('--no-browser'))return;
  const url=base+'/ddroid';
  const app=process.platform==='win32'?'cmd.exe':process.platform==='darwin'?'open':'xdg-open';
  const options=process.platform==='win32'?['/c','start','',url]:[url];
  const browser=spawn(app,options,{stdio:'ignore',detached:true});
  browser.on('error',()=>console.log('Open this address in your browser: '+url));browser.unref();
 }
 function ready(){
  if(done)return;
  const req=http.get(base+'/ddroid/state',res=>{
   let data='';res.on('data',c=>data+=c);res.on('end',()=>{try{if(JSON.parse(data).app==='DDROID'){done=true;openBrowser();return}}catch(_){}retry()});
  });
  req.on('error',retry);req.setTimeout(1000,()=>req.destroy());
 }
 function retry(){if(!done&&++attempts<40)timer=setTimeout(ready,500)}
 ready();
 child.on('error',e=>{console.error(e.message);done=true;clearTimeout(timer);process.exitCode=1});
 child.on('exit',code=>{done=true;clearTimeout(timer);process.exitCode=code||0});
 for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>{done=true;clearTimeout(timer);child.kill(sig)});
}
