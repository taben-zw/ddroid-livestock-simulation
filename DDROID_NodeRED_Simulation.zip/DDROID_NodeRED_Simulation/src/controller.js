'use strict';

// This pure JavaScript model is embedded into a Node-RED Function node by build-flow.js.
// Percentages and flow rates are illustrative, not a hydraulic calibration.
const DDROID = (() => {
  const limits = Object.freeze({low: 30, full: 85, cutoff: 95, sourceLow: 5, manual: 15});
  const clamp = n => Math.max(0, Math.min(100, n));
  function inputs(s) {
    return {
      lowWet: s.injections.conflict ? false : s.trough >= limits.low,
      highWet: s.injections.conflict ? true : s.trough >= limits.full,
      sourceLow: s.injections.dry || s.source <= limits.sourceLow,
      cutoff: s.injections.cutoff || s.trough >= limits.cutoff
    };
  }
  function log(s, type, detail) {
    const e = {id: ++s.eventId, seconds: s.seconds, type, detail};
    const target = s.network ? s.events : s.buffer;
    target.push(e);
    const max = s.network ? 200 : 100;
    if (target.length > max) {
      target.shift();
      if (!s.network) s.dropped++;
    }
  }
  function off(s, reason) {
    if (s.pump) log(s, 'PUMP_OFF', reason);
    s.pump = false;
    s.mode = 'IDLE';
    s.runSeconds = 0;
  }
  function trip(s, code, description) {
    off(s, description);
    s.armed = false;
    if (!s.fault) {
      s.fault = {code, description, acknowledged: false};
      log(s, 'FAULT', description);
    }
  }
  function immediateProtection(s) {
    if (inputs(s).cutoff) trip(s, 'HIGH_CUTOFF', 'Independent high-level cutoff is active.');
  }
  function sample(s) {
    const raw = inputs(s);
    const key = JSON.stringify(raw);
    s.filter.count = key === s.filter.candidate ? s.filter.count + 1 : 1;
    s.filter.candidate = key;
    if (s.filter.count >= 2) s.stable = {...raw};
  }
  function snapshot(s) {
    const i = s.stable;
    return {
      seconds: s.seconds, source: +s.source.toFixed(1), trough: +s.trough.toFixed(1),
      pump: s.pump, armed: s.armed, mode: s.mode, runSeconds: s.runSeconds,
      runLimit: s.runLimit, fault: s.fault ? {...s.fault} : null,
      level: !i ? 'SAMPLING' : !i.lowWet && i.highWet ? 'INVALID' : i.highWet ? 'FULL' : !i.lowWet ? 'LOW' : 'ADEQUATE',
      sensors: i ? {...i} : null, cycles: s.cycles
    };
  }
  function publish(s) {
    if (s.network) {
      s.telemetry = snapshot(s);
      s.history.push({seconds:s.seconds, trough:+s.trough.toFixed(1), source:+s.source.toFixed(1)});
      if (s.history.length > 120) s.history.shift();
    }
  }
  function create() {
    const s = {
      seconds: 0, source: 85, trough: 18, pump: false, armed: false, mode: 'IDLE',
      runSeconds: 0, runLimit: 60, cycles: 0, fault: null,
      demand: true, network: true, stable: null,
      injections: {dry:false, conflict:false, cutoff:false, blocked:false},
      filter: {candidate:'', count:0}, events:[], buffer:[], dropped:0, eventId:0,
      telemetry:null, history:[], seen:[]
    };
    log(s, 'STARTUP', 'Simulation started. Pump OFF; automatic control disarmed.');
    publish(s);
    return s;
  }
  function start(s, mode) {
    s.pump = true;
    s.mode = mode;
    s.runSeconds = 0;
    log(s, 'PUMP_ON', mode === 'AUTO' ? 'Automatic refill started at LOW.' : 'Manual fill started; maximum 15 seconds.');
  }
  function tick(s) {
    s.seconds++;
    // A blocked pipe prevents delivery. The timer still advances.
    if (s.pump) {
      s.runSeconds++;
      if (!s.injections.blocked && !s.injections.dry && s.source > limits.sourceLow) {
        const added = Math.min(3.8, s.source * 4, 100 - s.trough);
        s.trough = clamp(s.trough + added);
        s.source = clamp(s.source - added / 4);
      }
    }
    if (s.demand) s.trough = clamp(s.trough - 0.5);
    immediateProtection(s);
    sample(s);
    const i = s.stable;
    if (i) {
      if (i.sourceLow) trip(s, 'LOW_SUPPLY', 'Source supply is too low for pumping.');
      else if (!i.lowWet && i.highWet) trip(s, 'SENSOR_CONFLICT', 'Float readings are inconsistent.');
    }
    if (!s.fault && i) {
      if (s.pump && i.highWet) {
        if (s.mode === 'AUTO') s.cycles++;
        off(s, 'Trough FULL.');
      } else if (s.pump && s.mode === 'MANUAL' && s.runSeconds >= limits.manual) {
        off(s, 'Manual 15-second limit reached.');
      } else if (s.pump && s.runSeconds >= s.runLimit) {
        trip(s, 'RUN_TIMEOUT', 'Maximum pump run time reached.');
      }
      if (s.armed && !s.pump && !s.fault && !i.lowWet) start(s, 'AUTO');
    }
    publish(s);
    return s;
  }
  function safe(s) {
    const raw = inputs(s);
    const i = s.stable;
    return i && !i.sourceLow && !(!i.lowWet && i.highWet) &&
      !raw.sourceLow && !(!raw.lowWet && raw.highWet) && !raw.cutoff;
  }
  function act(s, action, value) {
    const remote = ['arm','manual','ack','reset_fault','run_limit'];
    if (remote.includes(action) && !s.network) throw new Error('Simulated Wi-Fi is offline. Reconnect, or use Local Stop.');
    switch (action) {
      case 'arm':
        if (s.fault) throw new Error('Clear the cause, then reset the latched fault before arming.');
        if (!safe(s)) throw new Error('Wait for two safe sensor samples before arming.');
        if (s.pump) throw new Error('Stop the current run before arming.');
        if (!s.armed) { s.armed = true; log(s,'ARMED','Automatic refill armed.'); }
        break;
      case 'manual':
        if (s.fault || !safe(s)) throw new Error('Manual fill requires safe inputs and no latched fault.');
        if (s.pump) throw new Error('Pump is already running. Stop it first.');
        if (s.stable.highWet || inputs(s).highWet) throw new Error('Trough is already full.');
        s.armed = false;
        start(s, 'MANUAL');
        break;
      case 'stop':
        off(s, 'Local Stop pressed.'); s.armed = false;
        log(s,'STOP','Local Stop: pump OFF and automatic mode disarmed.');
        break;
      case 'ack':
        if (!s.fault) throw new Error('There is no active fault.');
        s.fault.acknowledged = true;
        log(s,'ACKNOWLEDGED','Alarm acknowledged; fault remains latched.');
        break;
      case 'reset_fault':
        if (!safe(s)) throw new Error('Inputs are unsafe or still being sampled. Clear the cause and wait two seconds.');
        off(s,'Fault reset.'); s.armed = false; s.fault = null;
        log(s,'FAULT_RESET','Fault reset. Automatic mode remains disarmed.');
        break;
      case 'source': case 'trough':
        if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 100) throw new Error('Level must be a number from 0 to 100.');
        s[action] = value;
        log(s,'SCENARIO','Simulated '+action+' level set to '+value+'%.');
        break;
      case 'run_limit':
        if (!Number.isInteger(value) || value < 10 || value > 120) throw new Error('Run limit must be a whole number from 10 to 120 seconds.');
        if (s.pump) throw new Error('Stop the pump before changing its run limit.');
        s.runLimit = value;
        log(s,'SETTING','Maximum pump run set to '+value+' seconds.');
        break;
      case 'dry': case 'conflict': case 'cutoff': case 'blocked':
        if (typeof value !== 'boolean') throw new Error('Fault switch value must be true or false.');
        s.injections[action] = value;
        log(s,'SCENARIO',action+' simulation '+(value?'enabled.':'cleared.'));
        break;
      case 'demand':
        if (typeof value !== 'boolean') throw new Error('Demand value must be true or false.');
        s.demand = value;
        log(s,'SCENARIO','Livestock demand '+(value?'enabled.':'paused.'));
        break;
      case 'network':
        if (typeof value !== 'boolean') throw new Error('Network value must be true or false.');
        if (value !== s.network) {
          if (!value) log(s,'WIFI_LOST','Simulated Wi-Fi lost. Local controller continues.');
          s.network = value;
          if (value) {
            const count = s.buffer.length;
            s.events.push(...s.buffer); s.events = s.events.slice(-200); s.buffer = [];
            log(s,'WIFI_RESTORED',count+' buffered events recovered.');
          }
        }
        break;
      default: throw new Error('Unknown command.');
    }
    immediateProtection(s);
    publish(s);
    return s;
  }
  function view(s) {
    return {
      app:'DDROID', version:'2.0.0', seconds:s.seconds, limits,
      telemetry:s.telemetry, network:s.network,
      age:s.seconds-s.telemetry.seconds, stale:s.seconds-s.telemetry.seconds >= 15,
      buffered:s.buffer.length, dropped:s.dropped,
      injections:{...s.injections}, demand:s.demand,
      events:s.events.map(e=>({...e})), history:s.history.map(p=>({...p}))
    };
  }
  function command(s, body, now=Date.now()) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('Expected a JSON command.');
    if (typeof body.id !== 'string' || !/^[a-zA-Z0-9_-]{8,80}$/.test(body.id)) throw new Error('Command ID is missing or invalid.');
    if (!Number.isFinite(body.sentAt) || now-body.sentAt > 10000 || body.sentAt-now > 2000) throw new Error('Command has expired or has an invalid timestamp.');
    if (s.seen.includes(body.id)) throw new Error('Repeated command rejected.');
    if (typeof body.action !== 'string') throw new Error('Command action is required.');
    // Mark even rejected commands to prevent delayed replays when safety state changes.
    s.seen.push(body.id); if(s.seen.length>100) s.seen.shift();
    if (body.action === 'restart') { const next = create(); next.seen = [...s.seen]; return next; }
    return act(s,body.action,body.value);
  }
  function csv(s) {
    const quote = v => '"'+String(v).replace(/"/g,'""')+'"';
    return '\uFEFFid,simulation_seconds,event,detail\r\n'+s.events.map(e=>[e.id,e.seconds,e.type,e.detail].map(quote).join(',')).join('\r\n')+'\r\n';
  }
  return {limits,create,tick,act,view,command,csv,inputs};
})();
module.exports = DDROID;
