'use strict';
const fs=require('node:fs');
const path=require('node:path');
const root=__dirname;
const model=fs.readFileSync(path.join(root,'src','controller.js'),'utf8').replace(/module\.exports = DDROID;\s*$/,'');
const html=fs.readFileSync(path.join(root,'src','dashboard.html'),'utf8');
const tab='ddroid_flow_2000';
const node=(id,type,name,x,y,extra={})=>({id,type,z:tab,name,x,y,...extra});
const route=(id,url,method,x,y,wires)=>node(id,'http in',method.toUpperCase()+' '+url,x,y,{url,method,upload:false,swaggerDoc:'',wires:[wires]});
const topic=(id,name,t,x,y)=>node(id,'change',name,x,y,{rules:[{t:'set',p:'topic',pt:'msg',to:t,tot:'str'}],action:'',property:'',from:'',to:'',reg:false,wires:[['ddroid_engine']]});
const main=model+`\nlet state = context.get('ddroid') || DDROID.create();
let error = null;
try {
  if (msg.topic === 'tick') DDROID.tick(state);
  else if (msg.topic === 'command') state = DDROID.command(state, msg.payload);
} catch (e) { error = e.message; }
context.set('ddroid', state);
node.status({fill:state.fault?'red':state.pump?'green':'grey', shape:state.pump?'dot':'ring', text:state.fault?state.fault.code:state.pump?state.mode+' pump ON':state.armed?'Armed / waiting':'Disarmed / pump OFF'});
if (!msg.res) return [null, {payload:DDROID.view(state)}];
msg.statusCode = error ? 400 : 200;
msg.headers = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'};
if (msg.topic === 'csv') {
  msg.headers['Content-Type']='text/csv; charset=utf-8';
  msg.headers['Content-Disposition']='attachment; filename="DDROID_events.csv"';
  msg.payload=DDROID.csv(state);
} else {
  msg.payload=DDROID.view(state);
  if(error) msg.payload.error=error;
}
return [msg, null];`;
const flows=[
 {id:tab,type:'tab',label:'DDROID · Watering simulation',disabled:false,info:'Working Node-RED prototype for the DDROID livestock watering project. Open http://127.0.0.1:1880/ddroid. All sensor values are synthetic. Core nodes only. Main Function contains the inspectable controller. See README.md and VIBE_CODING_RECORD.md.'},
 node('ddroid_intro','comment','DDROID 2.0 | open /ddroid to run the simulation',380,40,{info:'No hardware required. Built-in nodes only. Use the provided launcher so the editor stays local. Initial state is pump OFF and automatic mode disarmed. Every inject tick represents one simulated second.'}),
 node('ddroid_clock','inject','1 Hz · simulated clock',180,140,{props:[{p:'topic',vt:'str'},{p:'payload'}],repeat:'1',crontab:'',once:true,onceDelay:'.2',topic:'tick',payload:'',payloadType:'date',wires:[['ddroid_engine']]}),
 route('ddroid_state','/ddroid/state','get',170,220,['ddroid_read']),
 topic('ddroid_read','Read telemetry','read',440,220),
 route('ddroid_command','/ddroid/command','post',180,300,['ddroid_cmd_topic']),
 topic('ddroid_cmd_topic','Validated command','command',440,300),
 route('ddroid_csv','/ddroid/events.csv','get',170,380,['ddroid_csv_topic']),
 topic('ddroid_csv_topic','Export received events','csv',440,380),
 node('ddroid_engine','function','Water model + safety controller',750,220,{func:main,outputs:2,timeout:3,noerr:0,initialize:'context.set("ddroid", null);',finalize:'',libs:[],wires:[['ddroid_api_response'],['ddroid_debug']],info:'Output 1 responds to dashboard/API requests. Output 2 exposes telemetry for the optional Debug pane. Safety: two-sample float filtering; explicit arm; full stop; dry-source and invalid-input latches; 10–120 s run timer; 15 s manual limit; immediate independent cutoff; local Stop; Wi-Fi telemetry freeze and 100-event buffer. This is an abstract software model, not firmware.'}),
 node('ddroid_api_response','http response','JSON / CSV response',1070,220,{statusCode:'',headers:{},wires:[]}),
 node('ddroid_debug','debug','Telemetry (enable to inspect)',1060,300,{active:false,tosidebar:true,console:false,tostatus:false,complete:'payload',targetType:'msg',statusVal:'',statusType:'auto',wires:[]}),
 node('ddroid_ui_note','comment','Dashboard | browser presents state; Node-RED runs the model',410,470,{info:'The browser sends commands and displays received telemetry. It does not run a substitute controller. During simulated Wi-Fi loss, telemetry freezes while the Node-RED model continues.'}),
 route('ddroid_page','/ddroid','get',160,540,['ddroid_html']),
 node('ddroid_html','template','Self-contained dashboard',450,540,{field:'payload',fieldType:'msg',format:'html',syntax:'plain',template:html,output:'str',wires:[['ddroid_page_response']]}),
 node('ddroid_page_response','http response','HTML response',750,540,{statusCode:'200',headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'},wires:[]})
];
fs.writeFileSync(path.join(root,'flows.json'),JSON.stringify(flows,null,2)+'\n');
console.log('Built flows.json: '+flows.length+' core nodes.');
