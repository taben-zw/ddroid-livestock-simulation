'use strict';
const path = require('node:path');
module.exports = {
  uiHost: '127.0.0.1',
  uiPort: Number(process.env.DDROID_PORT || 1880),
  httpAdminRoot: '/red',
  flowFile: path.join(__dirname, 'flows.json'),
  flowFilePretty: true,
  contextStorage: { default: { module: 'memory' } },
  functionExternalModules: false,
  functionTimeout: 3,
  apiMaxLength: '32kb',
  editorTheme: { projects: { enabled: false } },
  externalModules: { palette: { allowInstall: false }, modules: { allowInstall: false } },
  logging: { console: { level: 'info', metrics: false, audit: false } },
  // The project is a local, synthetic-data simulation. Do not expose its editor on a LAN.
  httpNodeMiddleware: function(req,res,next) {
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    if (req.method === 'POST') {
      const type = req.headers['content-type'] || '';
      if (!type.startsWith('application/json') || req.headers['x-ddroid'] !== '1') {
        res.status(415).json({error:'Use the local DDROID dashboard to send JSON commands.'});
        return;
      }
      if (req.headers.origin) {
        const allowed = ['http://127.0.0.1:'+Number(process.env.DDROID_PORT || 1880),'http://localhost:'+Number(process.env.DDROID_PORT || 1880)];
        if (!allowed.includes(req.headers.origin)) { res.status(403).json({error:'Origin rejected.'}); return; }
      }
    }
    next();
  }
};
