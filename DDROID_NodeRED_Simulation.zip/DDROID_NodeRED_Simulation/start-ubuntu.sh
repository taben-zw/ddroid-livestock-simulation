#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Install Node.js 24 LTS with npm from https://nodejs.org/en/download, then reopen the terminal."
  exit 1
fi
node check-node.js
if [ ! -f node_modules/node-red/red.js ] || [ ! -f node_modules/.ddroid-ready-5.0.8 ]; then
  echo "First setup: downloading the pinned Node-RED dependencies. Internet is required for this step."
  npm ci --omit=optional --no-audit --no-fund
  node -e "require('node:fs').writeFileSync('node_modules/.ddroid-ready-5.0.8','ready')"
fi
exec node start.js "$@"
