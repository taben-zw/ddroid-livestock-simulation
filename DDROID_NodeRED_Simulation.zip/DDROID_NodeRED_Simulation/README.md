# DDROID — Node-RED working simulation

**Smart Livestock Watering and Monitoring System · Prototype 2.0**

This package runs the watering simulation in **Node-RED 5.0.8**. A browser displays the tank, trough, pump, controls, alarms and event log. All measurements are synthetic. No hardware is needed.

## Recommended tools

Use **Node-RED** for this prototype. The same flow works on Ubuntu and Windows. The project uses built-in nodes only; there are no dashboard plugins or cloud accounts to configure.

| Person | Install once | Run the project |
| --- | --- | --- |
| Ubuntu user | Node.js **24 LTS**, including npm; a current browser | Extract the ZIP, then run `bash start-ubuntu.sh` in its folder |
| Windows user | Node.js **24 LTS**, including npm; Edge, Chrome or Firefox | Extract the ZIP, then double-click `start-windows.cmd` |

Node-RED is installed locally by the launcher. You do **not** need a separate global Node-RED installation. A code editor is optional; the Node-RED editor is included.

XOD also supports visual logic and an IDE simulation. It is a reasonable choice for microcontroller-focused work. ROS 2 with Gazebo is more appropriate when robot movement, a 3D environment or physics is central. DDROID's stationary watering control is a simpler match for Node-RED. Gazebo Harmonic's official Windows installation is marked experimental.

## 1. Install Node.js

Open **https://nodejs.org/en/download** and select **v24 LTS**.

### Ubuntu

1. Select **Linux** and follow the page's installation instructions. The official page offers a version-manager route using `nvm`.
2. If you already have `nvm`, run `nvm install 24`, then `nvm use 24`.
3. Open a new terminal and run `node --version` and `npm --version`.
4. The Node version should start with `v24.`. Keep the npm version supplied with it.

### Windows

1. Select **Windows** and download the Node.js **24 LTS installer (.msi)** for your computer's architecture. Most PCs use x64.
2. Run it with the normal options, including npm and PATH integration. This project does not require additional native build tools.
3. Close and reopen Command Prompt. Run `node --version` and `npm --version`.
4. The Node version should start with `v24.`. Installation may require administrator approval on a managed PC.

Node-RED 5 needs Node.js 22.9 or newer. This package was tested with Node.js 24.19.0; use the Node.js 24 LTS line on every group member's computer for consistency.

## 2. Start the simulation

**Extract the ZIP first. Do not run it inside the ZIP viewer.** Keep all files together.

Ubuntu: open a terminal inside the extracted `DDROID_NodeRED_Simulation` folder:

```bash
bash start-ubuntu.sh
```

Windows: double-click **start-windows.cmd** in that folder. If using Command Prompt instead:

```bat
start-windows.cmd
```

The first run downloads the exact dependencies in `package-lock.json`. **Internet is required for that first setup.** Once installation is complete, later runs work offline.

The launcher opens the browser when Node-RED is ready. If it does not open automatically, use:

- Simulation: **http://127.0.0.1:1880/ddroid**
- Node-RED flow editor: **http://127.0.0.1:1880/red/**

Keep the terminal open. Press **Ctrl+C** there to stop the server. Restarting or redeploying the controller resets its in-memory simulation; export the event CSV before closing if you need a record.

## 3. Share on WhatsApp

1. Send **DDROID_NodeRED_Simulation.zip** as a **Document** attachment.
2. Each teammate downloads the ZIP onto their PC and extracts it.
3. Each installs Node.js 24 LTS, then runs the appropriate launcher above.
4. They perform the short check below before the class demonstration.

The ZIP is a cross-platform project, not a self-contained `.exe`. Node.js and the first dependency download are prerequisites. Do not send your Linux `node_modules` folder to Windows users. Each PC installs the same pinned dependencies locally.

The localhost address is local to each PC; sending that address alone does not share the application. Each person's copy runs an independent simulation. WhatsApp is only the file-transfer method.

## 4. Five-minute demonstration

1. **Safe startup:** open the dashboard. Pump is OFF and automatic control is Disarmed. Wait two seconds for the floats to settle.
2. **Automatic refill:** click **Arm automatic refill**. The LOW trough starts refilling. Watch it reach FULL and stop, usually within about 25 seconds from the default levels.
3. **Low supply:** set the trough below 30%, wait for refill, then enable **Low supply fault**. The pump stops after two sensor samples and the fault latches.
4. **Acknowledge and reset:** click **Acknowledge**. The fault remains. Clear the low-supply switch, wait two seconds, then click **Reset fault**. The pump remains off and disarmed.
5. **Manual and Stop:** set the trough to 0%, then click **Manual fill · 15 seconds**. It stops within 15 seconds; **Local Stop** stops it immediately.
6. **Offline control:** reset the simulation, wait two seconds, arm automatic mode, then switch **Simulated Wi-Fi** off. Telemetry freezes and is marked stale after 15 seconds. Node-RED continues controlling the simulated pump. Reconnect to see fresh readings and recovered events.
7. **Evidence:** open **Node-RED flows** to show the Inject, Function, HTTP and Template nodes. Export the event CSV and explain the safety rules.

Additional fault demonstrations:

- **Conflicting floats:** enable the switch; two inconsistent samples latch a fault.
- **Independent cutoff:** enable it while pumping; the model stops immediately without the software filtering delay.
- **Blocked pipe / timeout:** reset, set maximum run to 10 seconds, enable Blocked pipe, wait for safe samples and arm. The timer stops the pump and latches a timeout after 10 seconds of pumping.

Scenario controls imitate local physical changes. They remain available during simulated Wi-Fi loss. Ordinary operator commands are rejected offline; **Local Stop** represents the wired stop.

## What is modelled

- Source tank and trough with illustrative percentage levels.
- Low float at 30%, high float at 85%, independent cutoff at 95%, source-low threshold at 5%.
- One tick per second; two consistent samples before accepting operating-float changes.
- Explicit arm, LOW-to-FULL automatic refilling and a 15-second maximum manual run.
- Configurable 10–120 second pump limit, initially 60 seconds; editable only when stopped.
- Latched dry-supply, inconsistent-sensor, timeout and cutoff faults.
- Acknowledgement separate from reset; reset and Local Stop leave control disarmed.
- Simulated network loss, 15-second stale flag and a 100-event local buffer. Oldest buffered events are dropped if capacity is exceeded, with a visible count.
- Rejection of repeated and expired commands; CSV export of received events.

The supply tank represents four times the trough's capacity. Pump delivery is 3.8 trough percentage points per tick, and optional animal demand removes 0.5 points per tick. These values make classroom demonstrations visible; they are **not measurements or a physical prediction**.

## Prototype scope

This is a **2D functional/control simulation**, not a 3D robot simulator. The main controller actually runs in the Node-RED Function node. The browser only renders telemetry and sends commands.

This is the throwaway prototype for requirements review. It is not the finished ESP32 firmware or the final Python/SQLite service described in the proposal. It has no physical pump driver, production user accounts, encrypted device link or persistent livestock database. The independent cutoff is represented in software; it does not validate a physical safety circuit.

The supplied settings bind the service to **127.0.0.1**, so the editor and controls are local to that PC. Keep that setting for the class simulation.

## Files and editing

| File | Purpose |
| --- | --- |
| `flows.json` | Complete importable Node-RED flow and dashboard |
| `settings.js` | Local runtime configuration |
| `start-ubuntu.sh` / `start-windows.cmd` | One launcher per operating system |
| `start.js` / `check-node.js` | Shared startup and version checks |
| `package.json` / `package-lock.json` | Exact Node-RED version and locked dependencies |
| `src/controller.js` | Readable controller and simulation source |
| `src/dashboard.html` | Readable dashboard source; served by Node-RED |
| `build-flow.js` | Embeds source files into `flows.json` |
| `tests/` | Repeatable automated controller/flow tests |
| `VIBE_CODING_RECORD.md` | Requirements prompt, decisions and review record |
| `TEST_RESULTS.txt` | Recorded checks and platform limitations |

For source-file edits, run `npm run build`, then restart Node-RED. This rebuild replaces `flows.json`, so export any edits made directly in the visual editor first. Changes made directly in Node-RED require **Deploy**.

If you already use a compatible Node-RED installation, import `flows.json` through **Menu → Import → select a file → Deploy**. The flow uses only core nodes. In that installation its dashboard uses `/ddroid` beneath your configured HTTP node root; the editor URL follows your existing settings. The supplied launchers are the simplest consistent setup for the group.

## Checks and troubleshooting

Run **`npm test`** in the project folder to repeat the 33 model and embedded-flow checks. This command does not require a running server.

Before class, each member should verify: dashboard opens; arm starts the pump; Local Stop stops it; a low-supply fault appears; CSV export downloads. Linux runtime and browser checks have been performed for this package. **The Windows launcher has not been executed on a Windows PC in this build environment.** Complete that short check on one teammate's Windows PC before distributing it to the whole group.

| Symptom | Action |
| --- | --- |
| `node` or `npm` not found | Install Node.js 24 LTS including npm; reopen the terminal |
| First setup fails | Check internet access and rerun the launcher; read the reported error |
| PowerShell blocks `npm.ps1` | Use the supplied `.cmd` launcher or Command Prompt; no policy change is needed |
| Port 1880 is busy | Stop the other Node-RED instance, or run `npm start -- --port 1881`; use the printed URLs |
| Browser says server unavailable | Keep the terminal running; restart it if it closed |
| Arm is disabled immediately after startup | Wait two seconds for the two operating-float samples |
| Reset is rejected | Clear the fault cause, restore a safe level, and wait two seconds |
| Offline values do not move | Re-enable Simulated Wi-Fi; frozen values are expected during that scenario |
| Windows file shows a warning | Check that it is this group's known ZIP; extract it and follow your school's device policy |

## Official references

Checked 16 October 2026:

- Node-RED local setup: https://nodered.org/docs/getting-started/local
- Node-RED on Windows: https://nodered.org/docs/getting-started/windows
- Supported Node.js versions: https://nodered.org/docs/faq/node-versions
- Node.js downloads: https://nodejs.org/en/download
- Sharing Node-RED flows: https://nodered.org/docs/user-guide/editor/workspace/import-export
- XOD simulation: https://xod.io/docs/tutorial/002-simulate/
- Gazebo Harmonic on Windows: https://gazebosim.org/docs/harmonic/install_windows/

Node-RED is an OpenJS Foundation project. This ZIP contains the team's prototype sources and a dependency manifest; the Node-RED runtime is downloaded during setup under its own license.
