'use strict';
const [major,minor]=process.versions.node.split('.').map(Number);
if(major<22 || (major===22 && minor<9)) {
 console.error('DDROID needs Node.js 22.9 or newer. Install Node.js 24 LTS from https://nodejs.org/en/download, then reopen this terminal.');
 process.exit(1);
}
console.log('Node.js '+process.versions.node+' detected.');
